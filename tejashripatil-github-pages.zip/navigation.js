(() => {
  const dock = document.querySelector(".section-dock");

  if (!dock) {
    return;
  }

  const links = Array.from(dock.querySelectorAll("a[data-section]"));
  const sections = links
    .map((link) => document.getElementById(link.dataset.section))
    .filter(Boolean);
  const parallaxSections = Array.from(
    document.querySelectorAll("main > section"),
  );
  const reducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)",
  ).matches;
  let updateQueued = false;

  const updateActiveSection = () => {
    const readingLine = window.innerHeight * 0.45;
    let activeSection = sections[0]?.id;

    dock.classList.toggle("is-scrolled", window.scrollY > 48);

    for (const section of sections) {
      if (section.getBoundingClientRect().top <= readingLine) {
        activeSection = section.id;
      }
    }

    for (const link of links) {
      const isActive = link.dataset.section === activeSection;
      link.classList.toggle("is-active", isActive);

      if (isActive) {
        link.setAttribute("aria-current", "location");
      } else {
        link.removeAttribute("aria-current");
      }
    }

  };

  const updateParallax = () => {
    if (reducedMotion) {
      return;
    }

    const viewportHeight = Math.max(window.innerHeight, 1);
    const viewportCenter = viewportHeight / 2;
    const shifts = parallaxSections.map((section) => {
      const bounds = section.getBoundingClientRect();
      const sectionCenter = bounds.top + bounds.height / 2;
      const distance = (sectionCenter - viewportCenter) / viewportHeight;
      const clampedDistance = Math.max(-1, Math.min(1, distance));

      return -clampedDistance * 18;
    });

    parallaxSections.forEach((section, index) => {
      section.style.setProperty(
        "--section-parallax",
        `${shifts[index].toFixed(2)}px`,
      );
    });
  };

  const updatePageEffects = () => {
    updateActiveSection();
    updateParallax();
    updateQueued = false;
  };

  const queueUpdate = () => {
    if (updateQueued) {
      return;
    }

    updateQueued = true;
    window.requestAnimationFrame(updatePageEffects);
  };

  window.addEventListener("scroll", queueUpdate, { passive: true });
  window.addEventListener("resize", queueUpdate);
  updatePageEffects();

  const resumeCue = document.querySelector(".floating-resume-cue");

  if (resumeCue instanceof HTMLCanvasElement && !reducedMotion) {
    const context = resumeCue.getContext("2d");

    if (context) {
      const baseSize = 120;
      const scale = resumeCue.width / baseSize;
      const curves = [
        [
          [14, 8],
          [12, 30],
          [28, 43],
          [49, 45],
        ],
        [
          [49, 45],
          [72, 47],
          [76, 24],
          [54, 23],
        ],
        [
          [54, 23],
          [35, 22],
          [27, 40],
          [38, 55],
        ],
        [
          [38, 55],
          [50, 70],
          [79, 75],
          [104, 101],
        ],
      ];

      const cubicPoint = (start, controlOne, controlTwo, end, amount) => {
        const inverse = 1 - amount;
        const inverseSquared = inverse * inverse;
        const amountSquared = amount * amount;

        return [
          inverseSquared * inverse * start[0] +
            3 * inverseSquared * amount * controlOne[0] +
            3 * inverse * amountSquared * controlTwo[0] +
            amountSquared * amount * end[0],
          inverseSquared * inverse * start[1] +
            3 * inverseSquared * amount * controlOne[1] +
            3 * inverse * amountSquared * controlTwo[1] +
            amountSquared * amount * end[1],
        ];
      };

      const points = [[curves[0][0][0] * scale, curves[0][0][1] * scale]];

      for (const curve of curves) {
        for (let step = 1; step <= 28; step += 1) {
          const point = cubicPoint(...curve, step / 28);
          points.push([point[0] * scale, point[1] * scale]);
        }
      }

      const drawSegment = (start, end, amount) => {
        context.lineTo(
          start[0] + (end[0] - start[0]) * amount,
          start[1] + (end[1] - start[1]) * amount,
        );
      };

      const drawResumeCue = (progress, opacity) => {
        context.clearRect(0, 0, resumeCue.width, resumeCue.height);
        context.globalAlpha = opacity;
        context.strokeStyle = getComputedStyle(resumeCue).color;
        context.lineWidth = 2.7 * scale;
        context.lineCap = "round";
        context.lineJoin = "round";

        const pathProgress = Math.min(progress / 0.84, 1);
        const exactPoint = pathProgress * (points.length - 1);
        const fullPointCount = Math.floor(exactPoint);

        context.beginPath();
        context.moveTo(points[0][0], points[0][1]);

        for (let index = 1; index <= fullPointCount; index += 1) {
          context.lineTo(points[index][0], points[index][1]);
        }

        if (fullPointCount < points.length - 1) {
          drawSegment(
            points[fullPointCount],
            points[fullPointCount + 1],
            exactPoint - fullPointCount,
          );
        }

        context.stroke();

        if (progress > 0.82) {
          const arrowProgress = Math.min((progress - 0.82) / 0.18, 1);
          const tip = [104 * scale, 101 * scale];
          const upperWing = [92 * scale, 98 * scale];
          const lowerWing = [102 * scale, 89 * scale];

          context.beginPath();
          context.moveTo(tip[0], tip[1]);
          drawSegment(tip, upperWing, arrowProgress);
          context.moveTo(tip[0], tip[1]);
          drawSegment(tip, lowerWing, arrowProgress);
          context.stroke();
        }
      };

      let cueFrame;

      const playResumeCue = () => {
        if (document.hidden) {
          return;
        }

        window.cancelAnimationFrame(cueFrame);
        let startTime;

        const drawFrame = (time) => {
          startTime ??= time;
          const elapsed = time - startTime;
          const drawProgress = Math.min(elapsed / 1900, 1);
          const easedProgress = 1 - Math.pow(1 - drawProgress, 2.3);
          const opacity =
            elapsed <= 1900 ? 1 : Math.max(0, 1 - (elapsed - 1900) / 650);

          drawResumeCue(easedProgress, opacity);

          if (elapsed < 2550) {
            cueFrame = window.requestAnimationFrame(drawFrame);
          } else {
            context.clearRect(0, 0, resumeCue.width, resumeCue.height);
          }
        };

        cueFrame = window.requestAnimationFrame(drawFrame);
      };

      let cueStartTimer;
      let cueInterval;

      const startResumeCueLoop = () => {
        window.clearTimeout(cueStartTimer);
        window.clearInterval(cueInterval);
        cueStartTimer = window.setTimeout(() => {
          playResumeCue();
          cueInterval = window.setInterval(playResumeCue, 10000);
        }, 450);
      };

      startResumeCueLoop();
      window.addEventListener("pageshow", (event) => {
        if (event.persisted) {
          startResumeCueLoop();
        }
      });
    }
  }
})();
