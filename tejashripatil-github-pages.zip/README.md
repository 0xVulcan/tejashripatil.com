# tejashripatil.com

Personal research portfolio for Tejashri Patil.
